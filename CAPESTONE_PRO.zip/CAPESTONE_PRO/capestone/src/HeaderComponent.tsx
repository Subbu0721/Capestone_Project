import React from 'react';

const Header = () => {
  return (
    <div className='header'>
    <header  >
        <span >Todo Management Application</span>
    </header>

</div>
   
  );
}

export default Header;