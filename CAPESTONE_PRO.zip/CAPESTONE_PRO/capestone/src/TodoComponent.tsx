import React, { useState, useEffect } from "react";
import axios from "axios";
import "./index.css";

interface Todo {
  id: number;
  todoTitle: string;
  todoDescription: string;
  todoCompleted: boolean;
}

function TodoComponent() {
  const [todos, setTodos] = useState<Todo[]>([]); 
  const [showInput, setShowInput] = useState(false); 
  const [newTodoTitle, setNewTodoTitle] = useState(""); 
  const [newTodoDescription, setNewTodoDescription] = useState("");
  const[newTodoCompleted,setNewTodoCompleted]=useState(false);
  const [selectedTodoId, setSelectedTodoId] = useState<number | null>(null);

  useEffect(() => {
    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/api/todos`);
      setTodos(response.data);
    } catch (error) {
      console.error("Error fetching todos:", error);
    }
  };

  const addTodo = async () => {
    try {
      const newTodo = {
        "todoTitle" : newTodoTitle,
        "todoDescription" : newTodoDescription,
        "todoCompleted" : newTodoCompleted
    };
      await axios.post(`http://localhost:8080/api/todos`, newTodo);
      fetchTodos();
      setNewTodoTitle("");
      setNewTodoDescription("");
      setShowInput(false);
    } catch (error) {
      console.error("Error adding todo:", error);
    }
  };

  const toggleInputVisibility = () => {
    setShowInput(!showInput);
    setSelectedTodoId(null); 
  };

  const handleUpdate = async () => {
    if (selectedTodoId !== null) {
      try {
        await axios.put(`http://localhost:8080/api/todos/${selectedTodoId}`, {
          todoTitle: newTodoTitle,
          todoDescription: newTodoDescription,
        });
        fetchTodos();
        setNewTodoTitle("");
        setNewTodoDescription("");
        setSelectedTodoId(null); 
        setShowInput(false);
      } catch (error) {
        console.error("Error updating todo:", error);
      }
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await axios.delete(`http://localhost:8080/api/todos/${id}`);
      fetchTodos();
    } catch (error) {
      console.error("Error deleting todo:", error);
    }
  };
  const complete = async (id: number) => {
    try {
      await axios.patch(`http://localhost:8080/api/todos/true/${id}`, { todoCompleted: true });
      fetchTodos();
    } catch (error) {
      console.log("Error marking todo as complete :", error);
    }
  };
  
const inComplete = async (id : number) => {
  try {
    await axios.patch(`http://localhost:8080/api/todos/false/` + id, {todoCompleted : !true});
    fetchTodos(); 
  } catch(error) {
    console.log("Error marking todo as incomplete :", error);
  }
}
function fetchData() {
  throw new Error("Function not implemented.");
}
  return (
    <div>
      <center>
        <h2>List of Todos</h2>
      </center>
      <div style={{ marginBottom: "10px" }}>
        <button className="AddButton" type="button" onClick={toggleInputVisibility}>
          {showInput ? "Cancel" : "Add Todo"}
        </button>
        {showInput && (
          <div style={{ display: "inline-block", marginLeft: "10px" }}>
            <input
              type="text"
              value={newTodoTitle}
              onChange={(e) => setNewTodoTitle(e.target.value)}
              placeholder="Enter todo title"
            />
            <input
              type="text"
              value={newTodoDescription}
              onChange={(e) => setNewTodoDescription(e.target.value)}
              placeholder="Enter todo description"
            />
            <button type="button" onClick={selectedTodoId !== null ? handleUpdate : addTodo}>
              {selectedTodoId !== null ? "Update" : "Save"}
            </button>
          </div>
        )}
      </div>
      <table className="TodoTable" >
        <thead >
          <tr>
            <th>Todo Title</th>
            <th>Todo Description</th>
            <th>Todo Completed</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {/* Render existing todos */}
          {todos.map((todo) => (
            <tr key={todo.id}>
              <td>{todo.todoTitle}</td>
              <td>{todo.todoDescription}</td>
              <td>{todo.todoCompleted ? "Yes" : "No"}</td>
              
              <td>
                <div>
                  <button
                    className="ActionButton UpdateButton"
                    onClick={() => {
                      setNewTodoTitle(todo.todoTitle);
                      setNewTodoDescription(todo.todoDescription);
                      setSelectedTodoId(todo.id);
                      setShowInput(true);
                    }}
                  >
                    Update
                  </button>
                  <button
                    className="ActionButton DeleteButton"
                    onClick={() => handleDelete(todo.id)}
                  >
                    Delete
                  </button>
                  <button
                    className="ActionButton CompleteButton"
                    onClick={() => complete(todo.id)}
                  >
                    Complete
                  </button>
                  <button
                    className="ActionButton IncompleteButton"
                    onClick={() => inComplete(todo.id)}
                  >
                    Incomplete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default TodoComponent;


