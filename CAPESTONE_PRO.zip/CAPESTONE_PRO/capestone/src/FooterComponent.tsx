import React from 'react'

const FooterComponent = () => {
  return (
    <div className='footer'>
        <footer >
            <span>Copyrights reserved </span>
        </footer>

    </div>
  )
}

export default FooterComponent