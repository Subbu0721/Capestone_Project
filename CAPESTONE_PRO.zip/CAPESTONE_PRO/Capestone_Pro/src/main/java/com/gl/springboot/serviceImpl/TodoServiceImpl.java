package com.gl.springboot.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.springboot.entity.TodoList;
import com.gl.springboot.exception.ResourceNotFoundException;
import com.gl.springboot.repository.TodoRepository;
import com.gl.springboot.service.TodoService;

@Service
public class TodoServiceImpl implements TodoService {

	@Autowired
    private TodoRepository todoRepository;

	@Override
	public TodoList addTodo(TodoList todoList) {
		TodoList list=todoRepository.save(todoList);
		return list;
	}

	@Override
	public TodoList getTodoById(Long id) {
		return todoRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Not found with id "+id));
		
	}

	@Override
	public List<TodoList> getAllTodos() {
		List<TodoList>list=todoRepository.findAll();
		return list;
	}

	@Override
	public TodoList updateTodo(Long id, TodoList todoList) {
		TodoList list=todoRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Not found with id "+id));
		list.setTodoTitle(todoList.getTodoTitle());
		list.setTodoDescription(todoList.getTodoDescription());
		
		TodoList updatedTodoList=todoRepository.save(list);
		return updatedTodoList;
	}

	@Override
	public void deleteTodo(Long id) {
		todoRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Not found with id"+id));
		todoRepository.deleteById(id);		
	}
	@Override
	public TodoList completeTodo(long id) {
		TodoList todo = todoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id : " + id));

        todo.setTodoCompleted(Boolean.TRUE);

        TodoList updatedTodo = todoRepository.save(todo);

        return updatedTodo;
	}
	
	@Override
	public TodoList inCompleteTodo(long id) {
		TodoList todo = todoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id : " + id));

        todo.setTodoCompleted(Boolean.FALSE);

        TodoList updatedTodo = todoRepository.save(todo);

        return updatedTodo;
	}

   
}
