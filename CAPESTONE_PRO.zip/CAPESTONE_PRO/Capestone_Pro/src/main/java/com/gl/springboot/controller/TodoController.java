package com.gl.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.springboot.entity.TodoList;
import com.gl.springboot.service.TodoService;

import lombok.AllArgsConstructor;

@CrossOrigin("*")
@AllArgsConstructor
@RestController
@RequestMapping("/api/todos")
public class TodoController {

	@Autowired
	private TodoService todoService;

	@PostMapping
	public ResponseEntity<TodoList> createTodo(@RequestBody TodoList todoList){
		TodoList todo = todoService.addTodo(todoList);
		return new ResponseEntity<>(todo, HttpStatus.CREATED);
	}    
	@GetMapping("{id}")
	public ResponseEntity<TodoList> getTodoById(@PathVariable("id") Long id){
		TodoList todoList = todoService.getTodoById(id);
		return ResponseEntity.ok(todoList);
	}

	// Build Get All Departments REST API
	@GetMapping
	public ResponseEntity<List<TodoList>> getAllTodos(){
		List<TodoList> todos = todoService.getAllTodos();
		return ResponseEntity.ok(todos);
	}

	// Build Update Department REST API
	@PutMapping("{id}")
	public ResponseEntity<TodoList> updateTodo(@PathVariable("id") Long id,
			@RequestBody TodoList updatedTodo){
		TodoList todoList = todoService.updateTodo(id, updatedTodo);
		return ResponseEntity.ok(todoList);
	}

	// Build Delete Department REST API
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteTodo(@PathVariable("id") Long id){
		todoService.deleteTodo(id);
		return ResponseEntity.ok("List deleted successfully!.");
	}
	@PatchMapping("true/{id}")
	public ResponseEntity<TodoList> completeTodo(@PathVariable("id") Long todoId){

		TodoList updatedTodo = todoService.completeTodo(todoId);
		return ResponseEntity.ok(updatedTodo);
	}

	@PatchMapping("false/{id}")
	public ResponseEntity<TodoList> inCompleteTodo(@PathVariable("id") Long todoId){

		TodoList updatedTodo = todoService.inCompleteTodo(todoId);
		return ResponseEntity.ok(updatedTodo);
	}

}
