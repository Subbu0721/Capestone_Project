package com.gl.springboot.service;

import java.util.List;

import com.gl.springboot.entity.TodoList;

public interface TodoService {

	TodoList addTodo(TodoList todoList);

	TodoList getTodoById(Long id);

	List<TodoList> getAllTodos();

	TodoList updateTodo(Long id, TodoList todoList);

	void deleteTodo(Long id);
	
	TodoList completeTodo(long id);

	TodoList inCompleteTodo(long id);
}
